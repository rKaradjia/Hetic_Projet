<?php
require_once( 'dbconfig.php' );

$sql = 'SELECT nom,description,datecreation,datedition,classement FROM tbl_film WHERE id ='. (int)$_GET['id'];
$results = $DB_con->query($sql);

?>
<ul>


    <?php
    while( $case = $results->fetchObject()){
        echo "<div>".$case->nom."</div>\n";
        echo "<div>".$case->description."</div>\n";
        echo "<div>".$case->datecreation."</div>\n";
        echo "<div>".$case->datedition."</div>\n";
        echo "<div>".$case->classement."</div>\n";

    }
    ?>


</ul>
