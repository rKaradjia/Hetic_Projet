<form action="tri_recherche.php" method="get">
    <input type="text" name="recherche" placeholder="recherche">
    <input type="submit" value="rechercher">
</form>
