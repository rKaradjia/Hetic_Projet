<?php
include_once 'dbconfig.php';
if(isset($_POST['btn-save']))
{
	$nom = $_POST['nom'];
	$description = $_POST['description'];
	$datecreation = $_POST['date_creation'];
	$datedition = $_POST['date_edition'];
    $classement = $_POST['classement'];
    $image = 'image/'.$_POST['image'];
	
	if($crud->create($nom,$description,$datecreation,$datedition,$classement,$image))
	{
		header("Location: add-data.php?inserted");
	}
	else
	{
		header("Location: add-data.php?failure");
	}
}
?>
<?php include_once 'header.php'; ?>
<div class="clearfix"></div>

<?php
if(isset($_GET['inserted']))
{
	?>
    <div class="container">
	<div class="alert alert-info">
    <strong>SUPER!</strong> L'enregistrement � �t� ins�r� avec succ�s
	</div>
	</div>
    <?php
}
else if(isset($_GET['failure']))
{
	?>
    <div class="container">
	<div class="alert alert-warning">
    <strong>DESOLE!</strong> Une erreur s'est produite pendant l'insertion d'un enregistrement !
	</div>
	</div>
    <?php
}
?>

<div class="clearfix"></div><br />

<div class="container">

 	
	 <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>Nom</td>
            <td><input type='text' name='nom' class='form-control' required></td>
        </tr>
 
        <tr>
            <td>Description</td>
            <td><input type='text' name='description' class='form-control' required></td>
        </tr>
 
        <tr>
            <td>Date Creation</td>
            <td><input type='text' name='date_creation' class='form-control' required></td>
        </tr>
 
        <tr>
            <td>Date Edition</td>
            <td><input type='text' name='date_edition' class='form-control' required></td>
        </tr>

        <tr>
            <td>Classement</td>
            <td><input type='text' name='classement' class='form-control' required></td>
        </tr>
        <tr>
            <td>image</td>
            <td><input type='file' name='image' class='form-control' required></td>
            <button type="submit" name="image">upload</button>
        </tr>
        <tr>
            <td colspan="2">
            <button type="submit" class="btn btn-primary" name="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Creer un nouvel enregistrement
			</button>  
            <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Retour � l'index</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>

<?php include_once 'footer.php'; ?>