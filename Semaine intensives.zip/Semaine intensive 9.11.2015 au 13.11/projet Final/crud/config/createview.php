<?php

require_once('dbconfig.php');

$sql = "SELECT
`id`,
`nom`,
`description`,
`datecreation`,
`datedition`,
`classement`,
`image`
FROM
`tbl_film`";

$stmt = $DB_con->prepare($sql);
$stmt->execute();

while($row=$stmt->fetch()) {
    ?>

    <div class="col-md-4 films-item">
        <a href="#filmsModal1" class="films-link" data-toggle="modal">
            <div class="films-hover">
                <div class="films-hover-content">
                    <i class="fa fa-plus fa-3x"></i>
                </div>
            </div>
            <img src="<?=$row['image']?>" class="img-responsive" alt="">
        </a>

        <div class="films-caption">
            <h5 class="id"><?= $row['id'] ?></h5>
            </br>
            <h4 class="nom">Titre du film : <p></p></br> <?= $row['nom'] ?></h4>
            </br>
            <p class="description">Description : </br> <?= $row['description'] ?></p>
            </br>
            <p class="datecreation">Date de creation :  <?= $row['datecreation'] ?></p>
            </br>
            <p class="datedition">Date d'edition :  <?= $row['datedition'] ?></p>
            </br>
            <p class="classement">Son classement dans notre top :  <?= $row['classement'] ?></p>
        </div>
    </div>

    <?php
}
?>


