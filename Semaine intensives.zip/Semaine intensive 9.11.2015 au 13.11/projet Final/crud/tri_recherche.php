<?php
require_once('dbconfig.php');
$sql = 'SELECT * FROM tbl_film WHERE nom LIKE \'%'. $_GET['recherche'].'%\' OR description LIKE \'%'. $_GET['recherche'].'%\' OR datecreation LIKE \'%'. $_GET['recherche'].'%\' OR datedition LIKE \'%'. $_GET['recherche'].'%\' OR classement LIKE \'%'. $_GET['recherche'].'%\' ORDER BY id';
$results = $DB_con->query($sql);
//var_dump($results->fetchAll(PDO::FETCH_OBJ));
?>
<ul>
    <?php
    while( $case = $results->fetchObject()){
        ?>
        <a href="Page_details.php?id=<?= $case->id ?>"><?= $case->nom?></a>
        <?php
    }
    ?>
</ul>