<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Medieval - fantastic Films">
    <meta name="author" content="Loris DUCAMPS">

    <title>Médiéval - Fantastic Wallpapers</title>

    <!-- Mon Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Mon CSS -->
    <link href="css/agency.css" rel="stylesheet">

    <!-- Les polices customs -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="index">


<!-- Navigation -->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Responsive pour l'affiche mobile -->
        <div class="navbar-header page-scroll">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand page-scroll" href="#page-top">MedieFilms / Medieval - Fantastic Movies</a>
        </div>

        <!-- Les liens Nav, formulaires et autres contenus -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li class="hidden">
                    <a href="#page-top"></a>
                </li>
                <li>
                    <a class="page-scroll" href="#films">Nos Affiches en HD</a>
                </li>

            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-avec animation fluide -->
</nav>

<!-- Header -->
<header>
    <div class="container">
        <div class="intro-text">
            <div class="intro-lead-in">Bienvenue sur notre catalogue</div>
            <div class="intro-heading">Faites vous plaisir !</div>
            <a href="#services" class="page-scroll btn btn-xl">En savoir plus</a>
        </div>
    </div>
</header>


    <?php


    require_once('dbconfig.php'); ?>




    <!-- Nos films Grille de selection -->
    <script src="js/jquery.js"></script>


<!-- Fin du while -->

    <!-- jQuery -->
<section id="films" class="bg-light-gray">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2 class="section-heading">Voici la selection de nos Affiches au top</h2>
                <h3 class="section-subheading text-muted">Découvrez les meilleurs Affiches.</h3>
            </div>
        </div>
        <?php include_once('config/createview.php') ?>

    </div>
</section>

<?php
require_once ('dbconfig.php');


$sql = "SELECT COUNT(id) AS nbPost FROM tbl_film LIMIT 3;";
$stmt = $DB_con->prepare($sql);
$stmt->execute();
$row = $stmt->fetch();

$nbPost = $row['nbPost'];
$perPage = 3;
$nbPage = ceil($nbPost/$perPage);

if(isset($_GET['p']) && $_GET['p'] > 0 && $_GET['p'] <= $nbPage){
$cPage = $_GET['p'];
} else {
$cPage = 1;
}

for($i = 1; $i <= $nbPage; $i++){
if($i == $cPage){
echo "$i /";
} else {
echo "<a href=\"index1.php?p=$i\">$i</a>/";
}
}
?>


<!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>

<!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

<!-- Custom Theme JavaScript -->
    <script src="js/agency.js"></script>
    <?php
    ?>
</body>
</html>