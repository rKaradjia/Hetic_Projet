<!DOCTYPE html>
<head>
<meta charset="utf-8"/>
<title>C.R.U.D Groupe 17</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"> 
</head>

<body>

<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
 
        <div class="navbar-header">
            <a class="navbar-brand"  title='Programming Blog'>CRUD</a>

        </div>
 
    </div>
</div>