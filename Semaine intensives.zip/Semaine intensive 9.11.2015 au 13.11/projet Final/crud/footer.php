<div class="container">
	<div class="alert alert-info">
    <strong>Groupe 17</strong>
	</div>
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
